<template>
  <div>
    <div v-text="msg"></div>
    <input type="text" v-model="newItem" @keyup.enter="addItem">
    <ul>
      <li v-for="item in items">
        <p v-text="item.label"></p>
      </li>
    </ul>
  </div>
</template>
<script>
  import Store from "../store"

  export default {
    name: "helloWorld",
    data() {
      return {
        msg: 1,
        items: Store.fetch(),
        newItem: ""
      }
    },
    methods: {
      addItem: function () {
        this.items.push({"label": this.newItem});
        this.newItem = "";
      }
    },
    watch: {
      items: {
        handler: function (items) {
          Store.save(items);
        },
        deep: true
      }
    }
  }
</script>
