import Vue from "vue"
import App from "./App.vue"
// var App = require("vue")

new Vue({
  el: "#app",
  template: "<App/>",
  components: {App}
});
