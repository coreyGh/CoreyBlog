<template>
  <div>
    <div class="colorRed">app.vue</div>
    <hello-world/>
  </div>
</template>
<script>
  import helloWorld from "./components/helloWorld.vue"

//  module.export = {
//
//  }
  export default {
    name: "app",
    components: {
      helloWorld
    }
  }
</script>
<style>
  .colorRed {
    color: red
  }
</style>
